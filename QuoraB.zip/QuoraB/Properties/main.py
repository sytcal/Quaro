from exploit_api import newb
from exploit_api.main import gyat
import os
from exploit_api.titties.instance import Instance
from exploit_api.titties.api import Memopy
import ctypes
import requests # type: ignore
from exploit_api.titties.utils import Offsets
import win32gui # type: ignore
import time
from pyfiglet import figlet_format as ascii
from exploit_api.titties.auto_dumper.offset_dumper import main as dump
import win32process
from exploit_api.titties.utils import GetRenderViewFromLog

main_dir = os.path.dirname(os.path.abspath(__file__))
autoexec_path = os.path.join(main_dir, "autoexec")
Window = None
Process = Memopy(0)
RenderView = GetRenderViewFromLog()
logo = ascii("QUORA")
global proto
proto = gyat()
proto.SetAutoExecPath(autoexec_path)
plrname = None
errors = {
    0x0: "Enjoy!",
    0x1: "Currently injecting!",
    0x2: "Failed to find Roblox process :(",
    0x3: "Failed to fetch DataModel :(",
    0x4: "Failed to fetch certain modules :(",
    0x5: "Roblox terminated while injecting!",
    0x6: "Failed to find Bridge :("
}

titles = {
     0x0: "Quora Injector (INJECTED :) )",
     0x1: "Quora Injector (INJECTING)",
     0x2: "Quora Injector (NO ROBLOX FOUND)",
     0x3: "Quora Injector (NO DATAMODEL :( )",
     0x4: "Quora Injector (FAILED TO FETCH MODULES)",
     0x5: "Quora Injector (FORCE STOPPED)",
     0x6: "Quora Injector (NO BRIDGE FOUND)"
}


if __name__ == "__main__":
    os.system("title Quora Injector")
    os.system("@echo off")
    os.system("cls")
    jk = 2
    if jk == 1:
        exit(0)
    else:
            if not win32gui.FindWindow(None, "Roblox"):
             while True:
                 time.sleep(2)
                 if not win32gui.FindWindow(None, "Roblox"):
                    print("Waiting for roblox..")
                 else:
                      input("Roblox Opened! Press Enter once you see the roblox window..")
                      break
            os.system('cls')
            print(logo)
            print("[*] Finding Roblox process...")
            print("[-] Found Roblox!")
            time.sleep(0.1)
            print("[*] Injecting modules...")
            time.sleep(0.1)
            print("[-] Injected Modules!")
            time.sleep(0.1)
            print("Injected! Please Join / Rejoin for the internal UI to show.")
            compiled = proto.Inject()
            print(errors.get(compiled, "Unknown error"))
            os.system('title ' + titles.get(compiled, "Unknown error"))          