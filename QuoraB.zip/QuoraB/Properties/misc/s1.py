VERSION = "1.1.6-dev"
class b1:
    Version = "1.0.0-dev"